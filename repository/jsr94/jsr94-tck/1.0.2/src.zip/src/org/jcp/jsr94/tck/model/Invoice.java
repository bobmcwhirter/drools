/*
 * J A V A  C O M M U N I T Y  P R O C E S S
 *
 * J S R  9 4
 *
 * Test Compatability Kit
 *
 */
package org.jcp.jsr94.tck.model;

/**
 * This interface defines the Invoice business object that is part of the
 * JSR-94 TCK.
 *
 * The Invoice interface exposes the following properties:<br>
 * <ul>
 * <li>description
 * <li>amount
 * <li>status
 * </ul>
 */
public interface Invoice
{
	/** Get the description of this invoice. */
	public abstract String getDescription();
	/** Set the description for this invoice. */
	public abstract void setDescription(String description);
	/** Get the payment amount for this invoice. */
	public abstract int getAmount();
	/** Set the payment amount for this invoice. */
	public abstract void setAmount(int amount);
	/** Get the status for this invoice. */
	public abstract String getStatus();
	/** Set the status for this invoice. */
	public abstract void setStatus(String status);
}