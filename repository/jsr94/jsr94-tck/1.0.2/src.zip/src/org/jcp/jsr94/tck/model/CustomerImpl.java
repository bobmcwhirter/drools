/*
 * J A V A  C O M M U N I T Y  P R O C E S S
 *
 * J S R  9 4
 *
 * Test Compatability Kit
 *
 */
package org.jcp.jsr94.tck.model;

/**
 * This class is a default JavaBean implementation of the Customer interface * for the JSR-94 TCK. Vendors with specific requirements for the implementation * class should see the org.jcp.jsr94.tck.util.TestFactory class used to * create instances of Customer.
 * * @version 1.0 * @since JSR-94 1.0.1
 */
public class CustomerImpl implements Customer 
{
	// The name of the customer.
	private String name;
	// The credit limit of the customer.
	private int creditLimit;
	
	/** Create an instance of the Customer class.
	 *
	 * @param name The name of the customer.
	 */
	public CustomerImpl(String name)
	{
		this.name = name;
	}

	/** Get the name of this customer. */
	public String getName()
	{
		return this.name;
	}

	/** Set the name of this customer. */
	public void setName(String name)
	{
		this.name = name;
	}
	/** Get the credit limit of this customer. */
	public int getCreditLimit()
	{
		return this.creditLimit;
	}

	/** Set the credit limit for this customer. */
	public void setCreditLimit(int creditLimit)
	{
		this.creditLimit = creditLimit;
	}
}
