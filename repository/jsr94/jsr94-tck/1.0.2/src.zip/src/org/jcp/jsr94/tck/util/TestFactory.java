/*
 * J A V A  C O M M U N I T Y  P R O C E S S
 *
 * J S R  9 4
 *
 * Test Compatability Kit
 *
 */
package org.jcp.jsr94.tck.util;

import java.util.Map;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.io.IOException;

import junit.framework.Assert;
import junit.framework.TestCase;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import org.jcp.jsr94.tck.model.Customer;
import org.jcp.jsr94.tck.model.CustomerImpl;
import org.jcp.jsr94.tck.model.Invoice;
import org.jcp.jsr94.tck.model.InvoiceImpl;

import javax.rules.admin.LocalRuleExecutionSetProvider;
import javax.rules.admin.RuleExecutionSetProvider;
import javax.rules.admin.RuleExecutionSet;
import javax.rules.admin.RuleAdministrator;

import javax.rules.RuleServiceProvider;
import javax.rules.ConfigurationException;
import javax.rules.admin.RuleExecutionSetCreateException;


/**
 * Factory class for the JSR-94 TCK. This class creates object instances
 * to be used in rule engine tests. This class allows rule engines that cannot
 * apply rules to the default model JavaBean implementation classes to substitute their
 * own implementations of the business model interfaces Customer and Invoice 
 * and the objects used for testing Handles.
 * <p>
 * The factory is also used to create the configuration Map instances to allow
 * rule engines to populate their configuration Maps required to pass the TCK.
 * 
 * @version 1.0
 * @since JSR-94 1.0.1
 */
public class TestFactory
{
	/**
	 * Protected constructor. Instances of this class should be created using 
	 * the newInstance method.
	 */
	protected TestFactory()
	{
	}
	
	/**
	 * Creates an instances of this factory class. The class returned is defined
	 * by the the property <code>test-factory</code> 
	 * in the tck.conf configuration file. This property should be set to a fully qualified 
	 * Java class name.
	 * 
	 * @return a TestFactory class instance.
	 */
	public static TestFactory newInstance()
	{
		String implClassName = TestCaseUtil.getTestFactory();
		
		if( implClassName == null )
		{
			throw new IllegalArgumentException( "Since JSR-94 1.1 the <test-factory> must be specified in the lib/tck.conf file. The default value for this property is org.jcp.jsr94.tck.util.TestFactory." );
		}
		
		try
		{
			return (TestFactory) Class.forName( implClassName ).newInstance();
		}
		catch( Exception e )
		{
			e.printStackTrace();
			throw new IllegalArgumentException( "Could not create custom TestObjectFactory. Exception: " + e );
		}
	}
	
	/**
	 * Creates the vendor specific configuration Map to be used
	 * when a RuleExecutionSet is being created. The default implementation
	 * returns null.
	 * 
	 * @return vendor configuration Map
	 */
	public Map createRuleExecutionSetMap()
	{
		return null;
	}
	
	/**
	 * Creates the vendor specific configuration Map to be used
	 * when a RuleExecutionSet is being registered using the 
	 * RuleAdministrator.registerRuleExecutionSet method. 
	 * The default implementation returns null.
	 * 
	 * @return vendor configuration Map
	 */
	public Map createRegisterRuleExecutionSetMap()
	{
		return null;
	}
	
	/**
	 * Creates the vendor specific configuration Map to be used
	 * when a RuleExecutionSet is being deregistered using the 
	 * RuleAdministrator.deregisterRuleExecutionSet method. 
	 * The default implementation returns null.
	 * 
	 * @return vendor configuration Map
	 */
	public Map createDeregisterRuleExecutionSetMap()
	{
		return null;
	}

	/**
	 * Creates the vendor specific configuration Map to be used
	 * when a LocalRuleExecutionSetProvider is being created. 
	 * The default implementation returns null.
	 * 
	 * @return vendor configuration Map
	 */
	public Map createLocalRuleExecutionSetProviderMap()
	{
		return null;
	}

	/**
	 * Creates the vendor specific configuration Map to be used
	 * when a RuleExecutionSetProvider is being created. 
	 * The default implementation returns null.
	 * 
	 * @return vendor configuration Map
	 */
	public Map createRuleExecutionSetProviderMap()
	{
		return null;
	}
	
	/**
	 * Creates a vendor specific RuleExecutionSet given a RuleServiceProvider
	 * and the URI to one of the TCK test rulesets.
	 * 
	 * The default implementation uses the LocalRuleExecutionSetProvider if implemented.
	 * If the LocalRuleExecutionSetProvider is not implemented it tries to use the
	 * RuleExecutionSetProvider by parsing the ruleset InputFile into an XML Document
	 * and passing the root Element of the Document to the RuleExecutionSetProvider.
	 */
	public RuleExecutionSet createRuleExecutionSet( RuleServiceProvider serviceProvider, String uri )
		throws ConfigurationException, RemoteException, RuleExecutionSetCreateException, IOException
	{
		RuleExecutionSet res = null;
		
		// try to get a local provider if one exists
		LocalRuleExecutionSetProvider localResProvider = serviceProvider.getRuleAdministrator().getLocalRuleExecutionSetProvider( createLocalRuleExecutionSetProviderMap() );
		
		if( localResProvider != null )
		{
			InputStream inStream =
				TestCaseUtil.getRuleExecutionSetInputStream( uri );

			TestCase.assertNotNull("[TestFactory] " +
				    "Input stream for " + uri + " could not be created.", inStream);
			
			res = localResProvider.createRuleExecutionSet( inStream, createRuleExecutionSetMap());			
			inStream.close();
		}
		else
		{
			// parse the input stream into a W3C document and then pass the root Element
			// to the non-local provider
			  Element element = TestCaseUtil.getRuleExecutionSetDocumentElement( uri );

			  RuleExecutionSetProvider resProvider = serviceProvider.getRuleAdministrator().getRuleExecutionSetProvider( createRuleExecutionSetProviderMap() );
			  res = resProvider.createRuleExecutionSet( element, createRuleExecutionSetMap() );
		}
		
	    TestCase.assertNotNull("[TestFactory] " +
			    "RuleExecutionSet for " + uri + " could not be created.", res );

		return res;
	}
	
	/**
	 * Creates the vendor specific configuration Map to be used
	 * when a RuleSession is being created. 
	 * The default implementation returns null.
	 * @param type the type of the RuleSession (from RuleRuntime)
	 * 
	 * @return vendor configuration Map
	 */
	public Map createRuleSessionMap( int type )
	{
		return null;
	}
	
	/**
	 * Returns an instance of the Customer interface. By default the
	 * factory will return the JavaBean implementation class supplied with
	 * the TCK.
	 * 
	 * @param name the initial name of the Customer
	 * @return a class that implements Customer
	 */
	public Customer createCustomer( String name )
	{
		return new CustomerImpl( name );
	}

	/**
	 * Returns an instance of the Invoice interface. By default the
	 * factory will return the JavaBean implementation class supplied with
	 * the TCK.
	 * 
	 * @param description the initial description for the Invoice
	 * @return a class that implements Invoice
	 */
	public Invoice createInvoice( String description )
	{
		return new InvoiceImpl( description );
	}

	/**
	 * Returns any valid Object that can be added or updated in a rule engine session. 
	 * By default the factory will return instances of the java.lang.String 
	 * class.
	 * 
	 * @param name the name of the Handle. This information can be safely ignored.
	 * @return a class that can be added to a rule session using addObject or updateObject.
	 */	
	public Object createHandleTestObject( String name )
	{
		return name;
	}
}
